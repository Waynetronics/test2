import { Command } from './sunoCommands';

export const advancedCommands: Command[] = [
  // Advanced Techniques
  { id: "31", name: "Fade In", syntax: "[Fade In]", description: "Gradual volume increase", examples: ["[Fade In: 4s]"], category: "Advanced Techniques" },
  { id: "32", name: "Fade Out", syntax: "[Fade Out]", description: "Gradual volume decrease", examples: ["[Fade Out]"], category: "Advanced Techniques", popular: true },
  { id: "33", name: "Tempo Change", syntax: "[Tempo: [bpm]]", description: "Change speed", examples: ["[Tempo: 140]"], category: "Advanced Techniques" },
  { id: "34", name: "Key Change", syntax: "[Key Change]", description: "Modulation", examples: ["[Key Change: Up]"], category: "Advanced Techniques" },
  { id: "35", name: "Drop", syntax: "[Drop]", description: "Bass drop moment", examples: ["[Bass Drop]", "[Drop: Heavy]"], category: "Advanced Techniques", popular: true },
  { id: "36", name: "Build Up", syntax: "[Build Up]", description: "Tension increase", examples: ["[Build Up: 8 bars]"], category: "Advanced Techniques" },
  { id: "37", name: "Glitch", syntax: "[Glitch]", description: "Glitch effect", examples: ["[Glitch Effect]"], category: "Advanced Techniques" },
  { id: "38", name: "Silence", syntax: "[Silence]", description: "Brief pause", examples: ["[Silence: 2s]"], category: "Advanced Techniques" },
  { id: "39", name: "Sidechain", syntax: "sidechain", description: "Pumping effect", examples: ["sidechain compression"], category: "Advanced Techniques" },
  { id: "40", name: "Stereo Width", syntax: "stereo: [width]", description: "Stereo field", examples: ["stereo: wide"], category: "Advanced Techniques" },
  { id: "41", name: "Layered", syntax: "layered [element]", description: "Multiple layers", examples: ["layered vocals"], category: "Advanced Techniques" },
  { id: "42", name: "Sampling", syntax: "sample: [source]", description: "Include samples", examples: ["sample: vinyl crackle"], category: "Advanced Techniques" },
  { id: "43", name: "Swing", syntax: "swing: [amount]", description: "Rhythmic swing", examples: ["swing: 60%"], category: "Advanced Techniques" },
  { id: "44", name: "Stutter", syntax: "[Stutter]", description: "Stuttering effect", examples: ["[Vocal Stutter]"], category: "Advanced Techniques" },
  { id: "45", name: "Pitch Shift", syntax: "pitch: [direction]", description: "Change pitch", examples: ["pitch: up"], category: "Advanced Techniques" },
  { id: "46", name: "Ambient Pad", syntax: "ambient pad", description: "Background atmosphere", examples: ["ambient pad: ethereal"], category: "Advanced Techniques" },
  { id: "47", name: "Arpeggio", syntax: "arpeggio", description: "Arpeggiated notes", examples: ["synth arpeggio"], category: "Advanced Techniques" },
  { id: "48", name: "Call Response", syntax: "[Call and Response]", description: "Musical dialogue", examples: ["[Call and Response: Vocals]"], category: "Advanced Techniques" },
];
