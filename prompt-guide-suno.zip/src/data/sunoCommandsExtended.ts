import { Command } from './sunoCommands';

export const extendedCommands: Command[] = [
  // Vocals & Instruments
  { id: "14", name: "Vocal Style", syntax: "vocals: [style]", description: "Define vocal character", examples: ["vocals: raspy", "vocals: smooth"], category: "Vocals & Instruments", popular: true },
  { id: "15", name: "Male/Female", syntax: "[gender] vocals", description: "Specify vocal gender", examples: ["male vocals", "female vocals"], category: "Vocals & Instruments" },
  { id: "16", name: "Harmony", syntax: "[Harmonies]", description: "Add vocal harmonies", examples: ["[Background Harmonies]"], category: "Vocals & Instruments" },
  { id: "17", name: "Acapella", syntax: "[Acapella]", description: "Vocals only", examples: ["[Acapella Section]"], category: "Vocals & Instruments" },
  { id: "18", name: "Instrument Focus", syntax: "featuring [instrument]", description: "Highlight instrument", examples: ["featuring saxophone", "featuring piano"], category: "Vocals & Instruments" },
  { id: "19", name: "808 Bass", syntax: "808 bass", description: "Heavy bass sound", examples: ["heavy 808 bass"], category: "Vocals & Instruments" },
  
  // Effects & Production
  { id: "20", name: "Reverb", syntax: "reverb: [amount]", description: "Add reverb effect", examples: ["reverb: heavy", "reverb: subtle"], category: "Effects & Production" },
  { id: "21", name: "Distortion", syntax: "distortion", description: "Add distortion", examples: ["guitar distortion"], category: "Effects & Production" },
  { id: "22", name: "Echo", syntax: "[Echo]", description: "Echo effect", examples: ["[Vocal Echo]"], category: "Effects & Production" },
  { id: "23", name: "Auto-tune", syntax: "auto-tune", description: "Pitch correction", examples: ["heavy auto-tune"], category: "Effects & Production" },
  { id: "24", name: "Lo-fi", syntax: "lo-fi", description: "Low fidelity sound", examples: ["lo-fi production"], category: "Effects & Production", popular: true },
  { id: "25", name: "Compression", syntax: "compressed", description: "Dynamic compression", examples: ["heavily compressed"], category: "Effects & Production" },
  
  // Lyrics Control
  { id: "26", name: "Repeat", syntax: "(x[number])", description: "Repeat line", examples: ["Yeah (x4)", "Oh no (x3)"], category: "Lyrics Control", popular: true },
  { id: "27", name: "Ad-lib", syntax: "[Ad-lib]", description: "Improvised vocals", examples: ["[Ad-lib: Yeah!]"], category: "Lyrics Control" },
  { id: "28", name: "Whisper", syntax: "[Whisper]", description: "Whispered vocals", examples: ["[Whisper: Come closer]"], category: "Lyrics Control" },
  { id: "29", name: "Shout", syntax: "[Shout]", description: "Shouted vocals", examples: ["[Shout: Hey!]"], category: "Lyrics Control" },
  { id: "30", name: "Spoken", syntax: "[Spoken]", description: "Spoken word", examples: ["[Spoken Word]"], category: "Lyrics Control" },
];
