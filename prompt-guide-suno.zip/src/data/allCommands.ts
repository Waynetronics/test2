import { commands } from './sunoCommands';
import { extendedCommands } from './sunoCommandsExtended';
import { advancedCommands } from './sunoCommandsAdvanced';

export const allCommands = [...commands, ...extendedCommands, ...advancedCommands];
export { categories } from './sunoCommands';
export type { Command } from './sunoCommands';
