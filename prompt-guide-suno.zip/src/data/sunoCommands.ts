export interface Command {
  id: string;
  name: string;
  syntax: string;
  description: string;
  examples: string[];
  category: string;
  popular?: boolean;
}

export const categories = [
  "Song Structure",
  "Genre & Style",
  "Vocals & Instruments",
  "Effects & Production",
  "Lyrics Control",
  "Advanced Techniques"
];

export const commands: Command[] = [
  // Song Structure
  { id: "1", name: "Intro", syntax: "[Intro]", description: "Marks the introduction section", examples: ["[Intro]", "[Intro: Piano]"], category: "Song Structure", popular: true },
  { id: "2", name: "Verse", syntax: "[Verse]", description: "Defines a verse section", examples: ["[Verse 1]", "[Verse 2]"], category: "Song Structure", popular: true },
  { id: "3", name: "Chorus", syntax: "[Chorus]", description: "Marks the chorus/hook", examples: ["[Chorus]", "[Chorus: Powerful]"], category: "Song Structure", popular: true },
  { id: "4", name: "Bridge", syntax: "[Bridge]", description: "Creates a bridge section", examples: ["[Bridge]", "[Bridge: Emotional]"], category: "Song Structure" },
  { id: "5", name: "Outro", syntax: "[Outro]", description: "Marks the ending section", examples: ["[Outro]", "[Outro: Fade]"], category: "Song Structure" },
  { id: "6", name: "Pre-Chorus", syntax: "[Pre-Chorus]", description: "Section before chorus", examples: ["[Pre-Chorus]"], category: "Song Structure" },
  { id: "7", name: "Instrumental", syntax: "[Instrumental]", description: "No vocals section", examples: ["[Instrumental Break]", "[Guitar Solo]"], category: "Song Structure", popular: true },
  { id: "8", name: "Break", syntax: "[Break]", description: "Pause or breakdown", examples: ["[Break]", "[Breakdown]"], category: "Song Structure" },
  
  // Genre & Style
  { id: "9", name: "Genre Tag", syntax: "genre: [style]", description: "Define music genre", examples: ["genre: synthwave", "genre: lo-fi hip hop"], category: "Genre & Style", popular: true },
  { id: "10", name: "BPM", syntax: "bpm: [number]", description: "Set tempo", examples: ["bpm: 120", "bpm: 85"], category: "Genre & Style" },
  { id: "11", name: "Key", syntax: "key: [note]", description: "Musical key", examples: ["key: C minor", "key: A major"], category: "Genre & Style" },
  { id: "12", name: "Mood", syntax: "mood: [feeling]", description: "Emotional tone", examples: ["mood: melancholic", "mood: uplifting"], category: "Genre & Style", popular: true },
  { id: "13", name: "Energy", syntax: "energy: [level]", description: "Intensity level", examples: ["energy: high", "energy: chill"], category: "Genre & Style" },
];
