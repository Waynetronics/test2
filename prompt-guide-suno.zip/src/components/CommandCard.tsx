import React, { useState } from 'react';
import { Command } from '../data/allCommands';

interface CommandCardProps {
  command: Command;
  onToggleFavorite: (id: string) => void;
  isFavorite: boolean;
}

export const CommandCard: React.FC<CommandCardProps> = ({ command, onToggleFavorite, isFavorite }) => {
  const [copied, setCopied] = useState(false);

  const handleCopy = (text: string) => {
    navigator.clipboard.writeText(text);
    setCopied(true);
    setTimeout(() => setCopied(false), 2000);
  };

  return (
    <div className="bg-gray-800/50 backdrop-blur-sm border border-gray-700 rounded-lg p-4 hover:border-purple-500 transition-all duration-300 hover:shadow-lg hover:shadow-purple-500/20">
      <div className="flex items-start justify-between mb-2">
        <h3 className="text-lg font-semibold text-white">{command.name}</h3>
        <button
          onClick={() => onToggleFavorite(command.id)}
          className="text-gray-400 hover:text-yellow-400 transition-colors"
        >
          {isFavorite ? '★' : '☆'}
        </button>
      </div>
      
      <div className="bg-gray-900 rounded px-3 py-2 mb-3 font-mono text-sm">
        <span className="text-purple-400">{command.syntax}</span>
      </div>
      
      <p className="text-gray-300 text-sm mb-3">{command.description}</p>
      
      <div className="space-y-2">
        <p className="text-xs text-gray-500 uppercase tracking-wide">Examples:</p>
        {command.examples.map((example, idx) => (
          <div key={idx} className="flex items-center justify-between bg-gray-900/50 rounded px-2 py-1">
            <code className="text-green-400 text-xs font-mono">{example}</code>
            <button
              onClick={() => handleCopy(example)}
              className="text-xs text-gray-400 hover:text-white transition-colors ml-2"
            >
              {copied ? '✓' : '📋'}
            </button>
          </div>
        ))}
      </div>
      
      {command.popular && (
        <span className="inline-block mt-3 px-2 py-1 bg-yellow-500/20 text-yellow-400 text-xs rounded">
          Popular
        </span>
      )}
    </div>
  );
};
