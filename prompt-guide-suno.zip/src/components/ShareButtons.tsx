import React from 'react';
import { Share2 } from 'lucide-react';

interface ShareButtonsProps {
  promptText: string;
}

export const ShareButtons: React.FC<ShareButtonsProps> = ({ promptText }) => {
  const handleTwitterShare = () => {
    const text = `🎵 Check out my Suno AI prompt:\n\n${promptText}\n\n#SunoAI #AIMusic`;
    const url = `https://twitter.com/intent/tweet?text=${encodeURIComponent(text)}`;
    window.open(url, '_blank', 'width=550,height=420');
  };

  const handleDiscordShare = () => {
    const formattedText = `🎵 **Suno AI Prompt**\n\`\`\`\n${promptText}\n\`\`\``;
    navigator.clipboard.writeText(formattedText);
    alert('Prompt copied to clipboard! Paste it in Discord.');
  };

  const handleRedditShare = () => {
    const title = 'My Suno AI Music Prompt';
    const text = `🎵 Suno AI Prompt:\n\n${promptText}`;
    const url = `https://reddit.com/submit?title=${encodeURIComponent(title)}&text=${encodeURIComponent(text)}`;
    window.open(url, '_blank');
  };

  return (
    <div className="flex gap-3 mt-4">
      <button
        onClick={handleTwitterShare}
        className="flex-1 bg-[#1DA1F2] hover:bg-[#1a8cd8] text-white px-4 py-2 rounded-lg font-semibold transition-all flex items-center justify-center gap-2"
      >
        <Share2 size={16} />
        Twitter
      </button>
      
      <button
        onClick={handleDiscordShare}
        className="flex-1 bg-[#5865F2] hover:bg-[#4752c4] text-white px-4 py-2 rounded-lg font-semibold transition-all flex items-center justify-center gap-2"
      >
        <Share2 size={16} />
        Discord
      </button>
      
      <button
        onClick={handleRedditShare}
        className="flex-1 bg-[#FF4500] hover:bg-[#e03d00] text-white px-4 py-2 rounded-lg font-semibold transition-all flex items-center justify-center gap-2"
      >
        <Share2 size={16} />
        Reddit
      </button>
    </div>
  );
};
