import React, { useState } from 'react';
import { Download } from 'lucide-react';

interface Command {
  id: string;
  name: string;
  syntax: string;
  description: string;
  category: string;
}

interface ExportMenuProps {
  commands: Command[];
  favorites: Set<string>;
}

export const ExportMenu: React.FC<ExportMenuProps> = ({ commands, favorites }) => {
  const [isOpen, setIsOpen] = useState(false);

  const exportAsJSON = () => {
    const favoriteCommands = commands.filter(cmd => favorites.has(cmd.id));
    const dataStr = JSON.stringify(favoriteCommands.length > 0 ? favoriteCommands : commands, null, 2);
    const dataBlob = new Blob([dataStr], { type: 'application/json' });
    const url = URL.createObjectURL(dataBlob);
    const link = document.createElement('a');
    link.href = url;
    link.download = `suno-commands-${Date.now()}.json`;
    link.click();
    URL.revokeObjectURL(url);
    setIsOpen(false);
  };

  const exportAsPDF = () => {
    const favoriteCommands = commands.filter(cmd => favorites.has(cmd.id));
    const exportCommands = favoriteCommands.length > 0 ? favoriteCommands : commands;
    
    const content = `
      <html>
        <head>
          <style>
            body { font-family: Arial, sans-serif; padding: 40px; background: #1a1a1a; color: #fff; }
            h1 { color: #a855f7; text-align: center; margin-bottom: 30px; }
            .command { background: #2d2d2d; border-left: 4px solid #a855f7; padding: 15px; margin-bottom: 20px; border-radius: 8px; }
            .command h3 { color: #60a5fa; margin: 0 0 10px 0; }
            .syntax { background: #1a1a1a; padding: 8px; border-radius: 4px; color: #a855f7; font-family: monospace; margin: 10px 0; }
            .description { color: #d1d5db; line-height: 1.6; }
            .category { display: inline-block; background: #374151; padding: 4px 12px; border-radius: 12px; font-size: 12px; color: #9ca3af; margin-bottom: 8px; }
          </style>
        </head>
        <body>
          <h1>🎵 Suno AI Command Cheat Sheet</h1>
          ${exportCommands.map(cmd => `
            <div class="command">
              <span class="category">${cmd.category}</span>
              <h3>${cmd.name}</h3>
              <div class="syntax">${cmd.syntax}</div>
              <p class="description">${cmd.description}</p>
            </div>
          `).join('')}
        </body>
      </html>
    `;
    
    const printWindow = window.open('', '_blank');
    if (printWindow) {
      printWindow.document.write(content);
      printWindow.document.close();
      setTimeout(() => {
        printWindow.print();
      }, 250);
    }
    setIsOpen(false);
  };

  return (
    <div className="relative">
      <button
        onClick={() => setIsOpen(!isOpen)}
        className="flex items-center gap-2 bg-gradient-to-r from-green-600 to-emerald-600 text-white px-6 py-3 rounded-lg font-semibold hover:from-green-700 hover:to-emerald-700 transition-all shadow-lg"
      >
        <Download size={20} />
        Export Collection
      </button>

      {isOpen && (
        <div className="absolute top-full mt-2 right-0 bg-gray-800 border border-gray-700 rounded-lg shadow-xl p-2 min-w-[200px] z-50">
          <button
            onClick={exportAsJSON}
            className="w-full text-left px-4 py-2 text-white hover:bg-gray-700 rounded transition-colors"
          >
            📄 Export as JSON
          </button>
          <button
            onClick={exportAsPDF}
            className="w-full text-left px-4 py-2 text-white hover:bg-gray-700 rounded transition-colors"
          >
            📑 Export as PDF
          </button>
          <div className="border-t border-gray-700 my-2"></div>
          <p className="px-4 py-2 text-xs text-gray-400">
            {favorites.size > 0 ? `Exporting ${favorites.size} favorites` : `Exporting all ${commands.length} commands`}
          </p>
        </div>
      )}
    </div>
  );
};
