import React, { useState } from 'react';
import { Link2, Check } from 'lucide-react';

interface SharePromptLinkProps {
  genre: string;
  mood: string;
  vocals: string;
  effects: string;
  structure: string;
}

export const SharePromptLink: React.FC<SharePromptLinkProps> = ({
  genre,
  mood,
  vocals,
  effects,
  structure
}) => {
  const [copied, setCopied] = useState(false);

  const generateShareableLink = () => {
    const params = new URLSearchParams({
      g: genre,
      m: mood,
      v: vocals,
      e: effects,
      s: structure
    });
    return `${window.location.origin}${window.location.pathname}?${params.toString()}#prompt-builder`;
  };

  const handleCopyLink = () => {
    const link = generateShareableLink();
    navigator.clipboard.writeText(link);
    setCopied(true);
    setTimeout(() => setCopied(false), 2000);
  };

  return (
    <button
      onClick={handleCopyLink}
      className="w-full bg-gradient-to-r from-blue-600 to-cyan-600 text-white py-3 rounded-lg font-semibold hover:from-blue-700 hover:to-cyan-700 transition-all flex items-center justify-center gap-2"
    >
      {copied ? (
        <>
          <Check size={20} />
          Link Copied!
        </>
      ) : (
        <>
          <Link2 size={20} />
          Generate Shareable Link
        </>
      )}
    </button>
  );
};
