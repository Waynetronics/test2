import React, { useState } from 'react';
import { Command } from '../data/allCommands';

interface PopularSidebarProps {
  popularCommands: Command[];
}

export const PopularSidebar: React.FC<PopularSidebarProps> = ({ popularCommands }) => {
  const [copied, setCopied] = useState<string | null>(null);

  const handleCopy = (text: string, id: string) => {
    navigator.clipboard.writeText(text);
    setCopied(id);
    setTimeout(() => setCopied(null), 2000);
  };

  return (
    <div className="bg-gray-800/50 backdrop-blur-sm border border-gray-700 rounded-xl p-6 sticky top-6">
      <div className="flex items-center gap-2 mb-4">
        <span className="text-2xl">⭐</span>
        <h3 className="text-xl font-bold text-white">Popular Commands</h3>
      </div>
      
      <div className="space-y-3">
        {popularCommands.map(cmd => (
          <div key={cmd.id} className="bg-gray-900/50 rounded-lg p-3 hover:bg-gray-900 transition-colors">
            <div className="flex items-start justify-between mb-2">
              <span className="text-sm font-semibold text-white">{cmd.name}</span>
              <button
                onClick={() => handleCopy(cmd.syntax, cmd.id)}
                className="text-xs text-gray-400 hover:text-white transition-colors"
              >
                {copied === cmd.id ? '✓' : '📋'}
              </button>
            </div>
            <code className="text-xs text-purple-400 font-mono">{cmd.syntax}</code>
          </div>
        ))}
      </div>
      
      <div className="mt-6 pt-6 border-t border-gray-700">
        <p className="text-xs text-gray-400 mb-2">💡 Quick Tip</p>
        <p className="text-sm text-gray-300">
          Combine multiple commands to create complex, layered compositions!
        </p>
      </div>
    </div>
  );
};
