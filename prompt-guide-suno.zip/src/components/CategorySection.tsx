import React, { useState } from 'react';
import { Command } from '../data/allCommands';
import { CommandCard } from './CommandCard';

interface CategorySectionProps {
  category: string;
  commands: Command[];
  favorites: Set<string>;
  onToggleFavorite: (id: string) => void;
}

export const CategorySection: React.FC<CategorySectionProps> = ({
  category,
  commands,
  favorites,
  onToggleFavorite
}) => {
  const [isExpanded, setIsExpanded] = useState(true);

  const categoryColors: Record<string, string> = {
    "Song Structure": "from-blue-500 to-cyan-500",
    "Genre & Style": "from-purple-500 to-pink-500",
    "Vocals & Instruments": "from-green-500 to-emerald-500",
    "Effects & Production": "from-orange-500 to-red-500",
    "Lyrics Control": "from-yellow-500 to-amber-500",
    "Advanced Techniques": "from-indigo-500 to-violet-500"
  };

  return (
    <div className="mb-8">
      <button
        onClick={() => setIsExpanded(!isExpanded)}
        className="w-full flex items-center justify-between mb-4 group"
      >
        <div className="flex items-center gap-3">
          <div className={`w-1 h-8 rounded bg-gradient-to-b ${categoryColors[category] || 'from-gray-500 to-gray-600'}`} />
          <h2 className="text-2xl font-bold text-white group-hover:text-purple-400 transition-colors">
            {category}
          </h2>
          <span className="bg-gray-700 text-gray-300 px-2 py-1 rounded text-sm">
            {commands.length}
          </span>
        </div>
        <span className="text-gray-400 text-2xl transform transition-transform duration-300" style={{ transform: isExpanded ? 'rotate(180deg)' : 'rotate(0deg)' }}>
          ▼
        </span>
      </button>
      
      {isExpanded && (
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
          {commands.map(command => (
            <CommandCard
              key={command.id}
              command={command}
              onToggleFavorite={onToggleFavorite}
              isFavorite={favorites.has(command.id)}
            />
          ))}
        </div>
      )}
    </div>
  );
};
