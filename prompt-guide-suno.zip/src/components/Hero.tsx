import React from 'react';

interface HeroProps {
  onScrollToCommands: () => void;
}

export const Hero: React.FC<HeroProps> = ({ onScrollToCommands }) => {
  return (
    <div 
      className="relative min-h-[500px] flex items-center justify-center overflow-hidden rounded-2xl mb-12"
      style={{
        backgroundImage: 'url(https://d64gsuwffb70l.cloudfront.net/68ffa36b8258bc1bb02087aa_1761584025450_405c007e.webp)',
        backgroundSize: 'cover',
        backgroundPosition: 'center'
      }}
    >
      <div className="absolute inset-0 bg-gradient-to-b from-purple-900/80 via-blue-900/70 to-gray-900/90" />
      
      <div className="relative z-10 text-center px-6 max-w-4xl">
        <div className="inline-block mb-4 px-4 py-2 bg-purple-500/20 backdrop-blur-sm rounded-full border border-purple-400/30">
          <span className="text-purple-300 text-sm font-semibold">🎵 Suno AI Reference Guide</span>
        </div>
        
        <h1 className="text-5xl md:text-7xl font-bold text-white mb-6 leading-tight">
          Master Suno AI
          <span className="block bg-gradient-to-r from-purple-400 to-blue-400 bg-clip-text text-transparent">
            Command Cheat Sheet
          </span>
        </h1>
        
        <p className="text-xl text-gray-300 mb-8 max-w-2xl mx-auto">
          Your complete reference for creating professional AI-generated music. 48+ commands, examples, and instant copy functionality.
        </p>
        
        <div className="flex flex-col sm:flex-row gap-4 justify-center">
          <button 
            onClick={onScrollToCommands}
            className="px-8 py-4 bg-gradient-to-r from-purple-600 to-blue-600 text-white font-bold rounded-lg hover:from-purple-700 hover:to-blue-700 transform hover:scale-105 transition-all shadow-lg shadow-purple-500/50"
          >
            Browse Commands →
          </button>
          <button 
            onClick={() => document.getElementById('prompt-builder')?.scrollIntoView({ behavior: 'smooth' })}
            className="px-8 py-4 bg-gray-800/70 backdrop-blur-sm text-white font-bold rounded-lg border border-gray-600 hover:bg-gray-700 transition-all"
          >
            Try Prompt Builder
          </button>
        </div>
        
        <div className="mt-12 flex items-center justify-center gap-8 text-sm text-gray-400">
          <div className="flex items-center gap-2">
            <span className="text-2xl">📚</span>
            <span>48+ Commands</span>
          </div>
          <div className="flex items-center gap-2">
            <span className="text-2xl">⚡</span>
            <span>Instant Copy</span>
          </div>
          <div className="flex items-center gap-2">
            <span className="text-2xl">🎯</span>
            <span>6 Categories</span>
          </div>
        </div>
      </div>
    </div>
  );
};
