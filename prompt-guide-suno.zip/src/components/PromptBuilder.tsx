import React, { useState, useEffect } from 'react';
import { ShareButtons } from './ShareButtons';
import { SharePromptLink } from './SharePromptLink';

export const PromptBuilder: React.FC = () => {
  const [genre, setGenre] = useState('synthwave');
  const [mood, setMood] = useState('energetic');
  const [vocals, setVocals] = useState('male');
  const [effects, setEffects] = useState('reverb');
  const [structure, setStructure] = useState('[Intro][Verse][Chorus][Verse][Chorus][Bridge][Chorus][Outro]');
  const [copied, setCopied] = useState(false);

  // Load from URL parameters on mount
  useEffect(() => {
    const params = new URLSearchParams(window.location.search);
    if (params.get('g')) setGenre(params.get('g')!);
    if (params.get('m')) setMood(params.get('m')!);
    if (params.get('v')) setVocals(params.get('v')!);
    if (params.get('e')) setEffects(params.get('e')!);
    if (params.get('s')) setStructure(params.get('s')!);
  }, []);

  const generatedPrompt = `genre: ${genre}, mood: ${mood}, ${vocals} vocals, ${effects}\n\n${structure}`;

  const handleCopy = () => {
    navigator.clipboard.writeText(generatedPrompt);
    setCopied(true);
    setTimeout(() => setCopied(false), 2000);
  };

  return (
    <div className="bg-gradient-to-br from-gray-800 to-gray-900 rounded-xl p-6 border border-gray-700">
      <h3 className="text-2xl font-bold text-white mb-4">🎵 Prompt Builder</h3>
      
      <div className="grid grid-cols-2 gap-4 mb-4">
        <div>
          <label className="block text-sm text-gray-400 mb-2">Genre</label>
          <select value={genre} onChange={(e) => setGenre(e.target.value)} className="w-full bg-gray-700 text-white rounded px-3 py-2 focus:outline-none focus:ring-2 focus:ring-purple-500">
            <option>synthwave</option>
            <option>lo-fi hip hop</option>
            <option>rock</option>
            <option>pop</option>
            <option>jazz</option>
          </select>
        </div>
        
        <div>
          <label className="block text-sm text-gray-400 mb-2">Mood</label>
          <select value={mood} onChange={(e) => setMood(e.target.value)} className="w-full bg-gray-700 text-white rounded px-3 py-2 focus:outline-none focus:ring-2 focus:ring-purple-500">
            <option>energetic</option>
            <option>melancholic</option>
            <option>uplifting</option>
            <option>chill</option>
          </select>
        </div>
        
        <div>
          <label className="block text-sm text-gray-400 mb-2">Vocals</label>
          <select value={vocals} onChange={(e) => setVocals(e.target.value)} className="w-full bg-gray-700 text-white rounded px-3 py-2 focus:outline-none focus:ring-2 focus:ring-purple-500">
            <option>male</option>
            <option>female</option>
            <option>smooth</option>
            <option>raspy</option>
          </select>
        </div>
        
        <div>
          <label className="block text-sm text-gray-400 mb-2">Effects</label>
          <select value={effects} onChange={(e) => setEffects(e.target.value)} className="w-full bg-gray-700 text-white rounded px-3 py-2 focus:outline-none focus:ring-2 focus:ring-purple-500">
            <option>reverb</option>
            <option>auto-tune</option>
            <option>distortion</option>
            <option>lo-fi</option>
          </select>
        </div>
      </div>
      
      <div className="bg-gray-900 rounded-lg p-4 mb-4">
        <pre className="text-green-400 text-sm font-mono whitespace-pre-wrap">{generatedPrompt}</pre>
      </div>
      
      <div className="space-y-3">
        <button onClick={handleCopy} className="w-full bg-gradient-to-r from-purple-600 to-blue-600 text-white py-3 rounded-lg font-semibold hover:from-purple-700 hover:to-blue-700 transition-all">
          {copied ? '✓ Copied!' : '📋 Copy Prompt'}
        </button>
        
        <SharePromptLink 
          genre={genre}
          mood={mood}
          vocals={vocals}
          effects={effects}
          structure={structure}
        />
        
        <ShareButtons promptText={generatedPrompt} />
      </div>
    </div>
  );
};

