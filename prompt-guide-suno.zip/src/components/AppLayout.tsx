import React, { useState, useMemo } from 'react';
import { Hero } from './Hero';
import { SearchBar } from './SearchBar';
import { CategorySection } from './CategorySection';
import { PopularSidebar } from './PopularSidebar';
import { PromptBuilder } from './PromptBuilder';
import { ExportMenu } from './ExportMenu';
import { Footer } from './Footer';
import { allCommands, categories } from '../data/allCommands';


const AppLayout: React.FC = () => {
  const [searchQuery, setSearchQuery] = useState('');
  const [favorites, setFavorites] = useState<Set<string>>(new Set());

  const handleScrollToCommands = () => {
    document.getElementById('commands')?.scrollIntoView({ behavior: 'smooth' });
  };

  const handleToggleFavorite = (id: string) => {
    setFavorites(prev => {
      const newSet = new Set(prev);
      if (newSet.has(id)) {
        newSet.delete(id);
      } else {
        newSet.add(id);
      }
      return newSet;
    });
  };

  const filteredCommands = useMemo(() => {
    if (!searchQuery.trim()) return allCommands;
    const query = searchQuery.toLowerCase();
    return allCommands.filter(cmd =>
      cmd.name.toLowerCase().includes(query) ||
      cmd.syntax.toLowerCase().includes(query) ||
      cmd.description.toLowerCase().includes(query) ||
      cmd.category.toLowerCase().includes(query)
    );
  }, [searchQuery]);

  const popularCommands = allCommands.filter(cmd => cmd.popular);

  return (
    <div className="min-h-screen bg-gradient-to-br from-gray-900 via-gray-800 to-gray-900">
      <div className="max-w-7xl mx-auto px-6 py-8">
        <Hero onScrollToCommands={handleScrollToCommands} />
        
        <div className="mb-8 flex flex-col sm:flex-row gap-4 items-center">
          <div className="flex-1 w-full">
            <SearchBar value={searchQuery} onChange={setSearchQuery} />
          </div>
          <ExportMenu commands={allCommands} favorites={favorites} />
        </div>


        <div className="flex flex-col lg:flex-row gap-8">
          <div className="flex-1" id="commands">
            {searchQuery ? (
              <div>
                <h2 className="text-2xl font-bold text-white mb-6">
                  Search Results ({filteredCommands.length})
                </h2>
                <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
                  {filteredCommands.map(cmd => (
                    <div key={cmd.id}>
                      {/* Inline simplified card for search results */}
                      <div className="bg-gray-800/50 backdrop-blur-sm border border-gray-700 rounded-lg p-4 hover:border-purple-500 transition-all">
                        <h3 className="text-lg font-semibold text-white mb-2">{cmd.name}</h3>
                        <code className="text-purple-400 text-sm">{cmd.syntax}</code>
                        <p className="text-gray-300 text-sm mt-2">{cmd.description}</p>
                      </div>
                    </div>
                  ))}
                </div>
              </div>
            ) : (
              categories.map(category => {
                const categoryCommands = allCommands.filter(cmd => cmd.category === category);
                return (
                  <CategorySection
                    key={category}
                    category={category}
                    commands={categoryCommands}
                    favorites={favorites}
                    onToggleFavorite={handleToggleFavorite}
                  />
                );
              })
            )}
            
            <div id="prompt-builder" className="mt-12">
              <PromptBuilder />
            </div>
          </div>

          <aside className="lg:w-80">
            <PopularSidebar popularCommands={popularCommands} />
          </aside>
        </div>
      </div>
      
      <Footer />
    </div>
  );
};

export default AppLayout;
